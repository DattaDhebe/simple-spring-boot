package com.ntt.spring;


// localhost://8096
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
@SpringBootApplication
public class SpringBootDemo1Application 
{

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemo1Application.class, args);
	}
	
	
	
	@RequestMapping(value = "/home")
	public String hello() 
	{
	      return "Hello World";
	}
	
	
	

}
